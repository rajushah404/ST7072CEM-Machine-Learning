# Crop Recommendation Using Soil and Climatic Parameters

**Raju Shah (260026) — ST7072CEM Machine Learning coursework**

The project compares three classification techniques for recommending one of 22 crops from 7 soil and
climate measurements: K-Nearest Neighbours, Decision Tree / Random Forest, and Gaussian Naive Bayes. PCA and
K-means are used to explore the feature space. Section 7 of the notebook contains an interactive crop
recommender prototype.

## Contents

```
Raju_Shah_260026_Project/
├── README.md                                    this file
├── requirements.txt                             Python package versions used
├── data/
│   └── Crop_recommendation.csv                  dataset (2,200 rows, 22 crops)
├── notebooks/
│   └── Raju_Shah_260026_CropRecommendation.ipynb   main notebook, all outputs included
├── figures/                                     20 figures produced by the notebook (300 dpi)
└── models/
    └── crop_recommender.joblib                  final trained Random Forest + label encoder
```

## Dataset

Crop Recommendation Dataset by Atharva Ingle, Kaggle:
<https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset>

| Column | Meaning | Unit |
|---|---|---|
| N, P, K | Nitrogen, phosphorus, potassium content of the soil | kg/ha |
| temperature | Average temperature | °C |
| humidity | Relative humidity | % |
| ph | Soil pH | – |
| rainfall | Rainfall | mm |
| label | Crop (22 classes, 100 rows each) | – |

A copy is included in `data/`. If the file is missing, the notebook downloads it automatically.

## Option A: Run locally (Jupyter)

Requirements: Python 3.10 or newer (tested on Python 3.12, Windows 11).

```bash
# 1. Open a terminal in the project folder
cd Raju_Shah_260026_Project

# 2. Create and activate a virtual environment
python -m venv .venv
.venv\Scripts\activate            # Windows
# source .venv/bin/activate       # macOS / Linux

# 3. Install the packages
pip install -r requirements.txt

# 4. Start Jupyter and open notebooks/Raju_Shah_260026_CropRecommendation.ipynb
jupyter notebook
```

In Jupyter, choose **Kernel → Restart Kernel and Run All Cells**. A full run takes about 3 minutes on a
laptop CPU. No GPU is needed.

To run it without opening the browser:

```bash
cd notebooks
jupyter nbconvert --to notebook --execute --inplace Raju_Shah_260026_CropRecommendation.ipynb
```

## Option B: Run in Google Colab

1. Go to <https://colab.research.google.com> → **File → Upload notebook** and pick
   `notebooks/Raju_Shah_260026_CropRecommendation.ipynb`.
2. Optional: upload `data/Crop_recommendation.csv` into a `data/` folder in the Colab file panel. If you skip
   this, the notebook downloads the dataset itself.
3. **Runtime → Run all.** Colab already has all the packages needed.

Figures and the trained model are saved to `figures/` and `models/` in the Colab session.

## What the notebook does

| Section | Content |
|---|---|
| 0 Setup | Imports, fixed random seed (42), paths |
| 1 EDA | Data quality checks, class balance, distributions, per-crop profiles, correlations, outliers, a test of within-crop distribution shape |
| 2 Pre-processing | Label encoding, stratified 80/20 split, scaling inside pipelines (no data leakage) |
| 3 Models | Grid-search tuning with stratified 5-fold CV on the training set |
| 4 Evaluation | Test metrics, per-class F1, confusion matrices, 10×5-fold repeated CV, corrected t-test and McNemar test, learning curves |
| 5 PCA & K-means | Explained variance, 2-D projection, elbow/silhouette, cluster–crop agreement (ARI, NMI) |
| 6 Robustness | Post-hoc feature importance and ablation, measurement noise, data scarcity, log-loss, Brier score, top-label ECE and reliability plots |
| 7 Prototype | Final Random Forest, `recommend()` with top-3 crops and an out-of-range warning, interactive form |

## Using the prototype

Run the last code cell of Section 7. Move the sliders for N, P, K, temperature, humidity, pH and rainfall, then
press **Recommend** to see the top 3 crops with probabilities. If a value lies outside the range seen in
training, a warning is shown.

To use the saved model from your own code:

```python
import joblib, numpy as np
b = joblib.load("models/crop_recommender.joblib")
x = np.array([[80, 45, 40, 23, 82, 6.5, 230]])   # N, P, K, temperature, humidity, ph, rainfall
proba = b["model"].predict_proba(x)[0]
print(b["label_encoder"].classes_[proba.argmax()], proba.max())   # rice
```

## Reproducibility

All random processes use seed 42, so repeated runs give the same metrics. Timing columns vary slightly
between machines. Parallel jobs use joblib's threading backend, which avoids a process-pool error that
sometimes occurs on Windows.

## Troubleshooting

| Problem | Fix |
|---|---|
| `FileNotFoundError` for the CSV and no internet | Put `Crop_recommendation.csv` in `data/` next to `notebooks/` |
| Interactive form does not appear | Run `pip install ipywidgets` and restart Jupyter. The worked examples above the form show the same output |
| `ModuleNotFoundError` | Make sure the `.venv` kernel is selected, or rerun `pip install -r requirements.txt` |
